#!/bin/env python
# -*- coding:utf-8 -*-

import conf.conf as var
from lib import remote, loggingcus, sendmessage


if __name__ == "__main__":
    
    execlogger = loggingcus.logger(var.ExecLog)
    
    for host in var.CallBackHost:
        newcallback = remote.RemoteCommand(host, var.SSHPort, var.CallBackExecUser)
        execlogger.info("Start CallBack on {}".format(host))
        print host
        
        stdres,stderr = newcallback._exec_comamnd(var.CallBackExecCmd)
        result = stdres + stderr
        mes = "Cmd: {}\nResult: {}".format(var.CallBackExecCmd, result)
        execlogger.info(host+mes)
        print mes

        text = "{}: {}".format(host, mes)
        for num in var.CallBackInfoNumber:
            sendmessage.sendsms(num, text)
        
         
        
        

