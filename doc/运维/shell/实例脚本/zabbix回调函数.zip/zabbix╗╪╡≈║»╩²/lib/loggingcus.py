#!/bin/env python
# -*- coding:utf-8 -*-
"""
Recod the log
"""
import logging
from logging.handlers import TimedRotatingFileHandler
from conf import conf


def logger(logfile):
    '''
    Return a logger handler.
    '''
    LOG_FILENAME = logfile
    LogKeepDays = conf.LogKeepDays
    LEVELS = {'noset':logging.DEBUG, 'debug':logging.DEBUG, 'info':logging.INFO, \
              'warning':logging.WARNING, 'error':logging.ERROR, 'critial':logging.CRITICAL}
    _name = logfile.split('/')[-1].split('.')[0]
    logger = logging.getLogger(_name)
    logger.setLevel(LEVELS.get('noset'))
    fh = TimedRotatingFileHandler(LOG_FILENAME, when='D', interval=1, backupCount=LogKeepDays)
    datefmt = '%Y-%m-%d %H:%M:%S'
    format_str = '[%(asctime)s %(levelname)s]  %(message)s'
    formatter = logging.Formatter(format_str, datefmt)
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

if __name__ == '__main__':
    logger('a.txt')
    