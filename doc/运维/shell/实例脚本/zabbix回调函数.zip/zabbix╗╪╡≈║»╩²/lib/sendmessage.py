#!/usr/bin/env python
#coding:utf-8
'''
Send sms script,useing for zabbix
'''
import requests
import datetime

URL = "http://your message url"

def sendsms(dest_number, text):
    #number_list = [dest_number]
    pars = {
        "OperID": "user",
        "OperPass": "pass",
        "DesMobile": dest_number,
        "Content": text.decode('utf-8').encode('gbk', 'ignore'),
        "ContentType": 8,
    }

    rep = requests.get(URL, params=pars)
    #print rep.text
    if rep.status_code != 200:
        print "Message Send Failed"
    else:
        print "Message Send Success"

if __name__ == '__main__':
    msg = 'test111'
    number_list = '112'
    sendsms(number_list, msg)




