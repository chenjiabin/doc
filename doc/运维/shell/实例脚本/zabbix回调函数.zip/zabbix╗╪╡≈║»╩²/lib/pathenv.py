#!/bin/env python
# -*- coding:utf-8 -*-
'''
The path of all modules
'''
# 模块路径定义
import os, sys
basedir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
sys.path.append(basedir)
