#!/bin/env python
# -*- coding:utf-8 -*-

import paramiko
import conf.conf as var

class RemoteCommand():
    def __init__(self, host, port, user, password=var.Password):
        self._host = host
        self._port = port
        self._user = user
        self._password = password
    def _ssh_connect(self):
        s = paramiko.SSHClient()
        if var.SSHDebug:
            paramiko.util.log_to_file(var.LogBaseDir+"ssh.log", 1)
        s.load_system_host_keys()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        if len(self._password) == 0:
            pkey_file = var.PrivateKey
            key = paramiko.RSAKey.from_private_key_file(pkey_file)
            s.connect(self._host,self._port,self._user,pkey=key,timeout=5)
        else:
            s.connect(self._host,self._port,self._user,self._password,timeout=5)
        return s

    def _exec_comamnd(self, cmd):
        try:
            s = self._ssh_connect()
        except Exception as e:
            print "{}".format(e)
            return ('Error, ',"{}".format(e))
        _,stdout,stderr = s.exec_command(cmd)
        cmd_result = stdout.read(),stderr.read()
        return cmd_result