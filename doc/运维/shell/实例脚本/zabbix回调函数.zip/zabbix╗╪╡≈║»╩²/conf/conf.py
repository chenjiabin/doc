#!/bin/env python
# -*- coding:utf-8 -*-

from __future__ import with_statement
import os
import os.path as path 
import ConfigParser

basedir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

ConfigFile = path.join(path.dirname(path.realpath(__file__)), 'config.conf')
config=ConfigParser.ConfigParser() 
with open(ConfigFile, 'r+') as cfgfile:
    config.readfp(cfgfile)
    CallBackAppName = config.get('CallInfo', 'CallBackAppName')
    BaseVars = {'BaseDir':basedir}
    LogBaseDir = config.get('LOG', 'LogBaseDir', vars = BaseVars)
    
    SSHPort = config.getint('System', 'SSHPort')
    PrivateKey = config.get('System', 'PrivateKey')
    Password = config.get('System', 'Password')
    SSHDebug = config.getboolean('System', 'SSHDebug')
    
    LogVars = {'LogBaseDir':LogBaseDir, 'CallBackAppName':CallBackAppName}
    if not path.isdir(LogBaseDir):os.makedirs(LogBaseDir)
    
    ExecLog =config.get('LOG', 'ExecLog', vars=LogVars)
    LogKeepDays = config.getint('LOG', 'LogKeepDays')
    
    CallBackHost = config.get('CallInfo', 'CallBackHost').split(',')
    CallBackExecUser = config.get('CallInfo', 'CallBackExecUser')
    CallBackExecCmd = config.get('CallInfo', 'CallBackExecCmd')
    CallBackInfoNumber = config.get('CallInfo', 'CallBackInfoNumber').split(',')
cfgfile.close()

#print   ExecLog