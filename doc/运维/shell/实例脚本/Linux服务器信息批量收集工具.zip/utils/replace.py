import string

template_text = "This is a example $$abc"

template_dict = {'abc':'aabbcc'}

class MyTemplate(string.Template):
    delimiter = "$$"
    idpattern = r'[_a-z][_a-z0-9]*'
    
    def __init__(self, template, template_dict):
        string.Template.__init__(self, template)
        self.template_dict = template_dict
    def replace(self):
        return self.safe_substitute(self.template_dict)
