import os
import subprocess

def handle_command(command):
    _old_command = command
    command = " ".join(_old_command[2:])
    mytask = subprocess.Popen(command, shell=True,stdin=subprocess.PIPE, 
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    result = mytask.stdout.readlines()
    return [{'title':_old_command[1], 'level':2, 'command':command, 'result':result}]
def level_length(filename):
    _lfilename = filename.rstrip('/').split('/')
    return len(_lfilename)
def handle_only_directory(_dir):
    return [{'title':_dir, 'level':level_length(_dir)+1, 'result':[]}]

def generate_directory_structure(_dir):
    _dir_structure = []
    if os.path.isdir(_dir):
        pass
    elif os.path.isfile(_dir):
        _dir = os.path.dirname(_dir)
    _dir_split = _dir.rstrip('/').split('/')
    for i in range(len(_dir_split)):
        _next_dir = "/".join(_dir_split[:i+1])
        _dir_structure.extend(handle_only_directory(_next_dir))
    return _dir_structure
    
def handle_file(filename):
    _file_structure = []
    if os.path.isfile(filename):
        f = open(filename, 'r')
        result = f.readlines()
        f.close()
        res = [i for i in result if not i.startswith('#')]
    else:
        res = ["File is not exist!"]
    _file_structure.extend(generate_directory_structure(filename))
    _file_structure.extend([{'title':filename, 'level':level_length(filename)+1, 'result':res}])
    return _file_structure
    
def handle_directory(directory):
    _file_result_list = []
    if os.path.isdir(directory):
        for _flist in list(os.walk(directory)):
            if len(_flist[2]) == 0:continue
            #add the directory title
            _file_result_list.extend(generate_directory_structure(_flist[0]))
            for single_flist in _flist[2]:
                _relative_file_name = os.path.join(_flist[0],single_flist)
                _file_result_list.extend(handle_file(_relative_file_name))
    else:
        _file_result_list = [{'title':directory, 'level':level_length(directory), 'result':["Directory is not exist!"]}]
    return _file_result_list


def handle_interface(linfo):
    def dict_in_list_no_duplicate(_list,single):
        _new_list = []
        _new_list_single = []
        for x in _list:
            if x[single] not in _new_list_single:
                _new_list.append(x)
                _new_list_single.append(x[single])
        return _new_list
    if len(linfo) == 1:
        single_linfo = linfo[0].rstrip('\n').split()
        if single_linfo[0] == 'command':
            return handle_command(single_linfo)
    else:
        _collection = []
        for single_linfo in linfo:
            single_linfo = single_linfo.rstrip('\n').split()
            if single_linfo[0] == 'file':
                _collection.extend(handle_file(single_linfo[1]))
            elif single_linfo[0] == 'directory':
                _collection.extend(handle_directory(single_linfo[1]))
        
        _collection = dict_in_list_no_duplicate(_collection, 'title')
        return sorted(_collection, lambda x,y:cmp(x['title'],y['title']))
