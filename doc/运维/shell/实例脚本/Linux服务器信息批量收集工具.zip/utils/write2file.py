import os
import time

hostname = os.popen('hostname').read().strip('\n')
current_date = time.strftime("%Y-%m-%d",time.localtime())
file_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
file_name = os.path.join(file_dir,"ServerReport-%s-%s.html" % (hostname, current_date))

def wstr(_wstr):
    f = open(file_name, 'a')
    f.writelines(_wstr)
    f.close()