# -*- coding:utf-8 -*-
'''
Generate local server information manully.
''''
import sys,os
from utils import scaninfo,replace,write2file
from setting import ConfigrationParse

base_dir = os.path.dirname(os.path.realpath(__file__))
info_file = os.path.join(base_dir,ConfigrationParse.InfoFile)


def template_reader(template_name):
    f = open(template_name, 'r')
    res = f.read()
    f.close()
    return res

def template_replace(_template_name, _template_dict):
    template_name = os.path.join(base_dir,'template',_template_name)
    _o_template = template_reader(template_name)
    t = replace.MyTemplate(_o_template,_template_dict)
    fin_str = t.replace()
    return fin_str

#handle the info file
try: 
    _finfo = open(info_file, 'r')
    _linfo = _finfo.readlines()
    _finfo.close()
except:
    print "INFO.txt can't be open,Please check"
    sys.exit()

def res_handle(_res):
    _body = ""
    _total_table_content = ""
    for _single_res_dict in _res:
        #handle title
        _title_template_dict = {'title_level':_single_res_dict['level'] , 'title':_single_res_dict['title']}
        _title_fin_str = template_replace('ReportTitle.html', _title_template_dict)
        #handle result
        _content = ""
        if _single_res_dict.has_key('command'):
            _tr_command_template_dict = {'content':("<b># "+_single_res_dict['command']+"</b>").replace(" ","&nbsp;")}
            _content += template_replace('ReportSingleTrContent.html', _tr_command_template_dict)
        for per_line in _single_res_dict['result']:
            _tr_template_dict = {'content':per_line.rstrip('\n').replace(" ","&nbsp;")}
            _content += template_replace('ReportSingleTrContent.html', _tr_template_dict)
        _table_template_dict = {'tr_content':_content}
        _table =  template_replace('ReportTable.html', _table_template_dict)
        _total_table_content += _title_fin_str + _table        
    _body += _total_table_content
    return _body
_collection = []
_total_body = ""
for single_linfo in _linfo:
    if single_linfo.startswith('file') or single_linfo.startswith('directory'):
        #collect all file and directory information
        _collection.append(single_linfo)
    elif single_linfo.startswith('command'):
        # handle the command
        _res = scaninfo.handle_interface([single_linfo])
        _total_body += res_handle(_res)

#Add the Other content
_title_server_information_dict = [{'level':1 , 'title':"Server Base Information",
                                  'result':[
                                            'HOSTNMAE:&nbsp;    %s' % write2file.hostname,
                                            'TIME:&nbsp;    %s' % str(write2file.current_date)
                                            ]}]
_title_server_information = res_handle(_title_server_information_dict)
_title_system_information_template_dict = {'title_level':1 , 'title':"System Information"}
_title_system_information = template_replace('ReportTitle.html', _title_system_information_template_dict)
_title_configuration_information_template_dict = {'title_level':1 , 'title':"Configuration Information"} 
_title_configuration_information = template_replace('ReportTitle.html', _title_configuration_information_template_dict)
#handle the file and directory after collection
_res = scaninfo.handle_interface(_collection)
_total_body = _title_server_information + _title_system_information + _total_body + \
                _title_configuration_information + res_handle(_res)
_body_template_dict = {'body':_total_body}
_total_html = template_replace('Report.html', _body_template_dict)
write2file.wstr(_total_html)

    