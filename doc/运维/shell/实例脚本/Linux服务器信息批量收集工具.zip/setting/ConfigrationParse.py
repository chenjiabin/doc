#!/bin/env python
# -*- coding:utf-8 -*-

from __future__ import with_statement
import os.path as path 
import ConfigParser
ConfigFile = path.join(path.dirname(path.realpath(__file__)), 'config.ini')
config=ConfigParser.ConfigParser() 
with open(ConfigFile,'r+') as cfgfile:
    config.readfp(cfgfile)
    _vars = {'BaseDir':config.get('DIR', 'BaseDir')}

    HostFile = config.get('Host', 'HostFile', vars = _vars)
    Password = config.get('Host', 'Password')
    
    InfoFile = config.get('INFO', 'InfoFile', vars = _vars)
    print InfoFile
cfgfile.close()