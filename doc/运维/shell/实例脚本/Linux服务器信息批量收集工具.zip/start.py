from mutliop import remote_interactive
from setting import ConfigrationParse
import threading
import os,sys

local_file_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))),"Report")
if not os.path.isdir(local_file_dir):os.makedirs(local_file_dir)
directory = os.path.dirname(os.path.realpath(__file__))
password = ConfigrationParse.Password

class MyThread(threading.Thread):
    def __init__(self, func, args, name=''):
        threading.Thread.__init__(self)
        self.name = name
        self.func = func
        self.args = args
        self.name = name
    def run(self):
        self.func(*self.args)

def _generate_report(directory, host, port, user):
    remote_dir = '/root/'
    remote_report_dir =  os.path.join(remote_dir,"ServerReport")
    remote_exec_file = os.path.join(remote_report_dir,"generate.py")
    
    print "%s:(2/11) Apply to set an transmission" % host
    nc = remote_interactive.OP_LOCAL_DIR(directory, host, port, user, password)
    print "%s:(3/11) Begin to Transmist the op file" % host
    nc._sftp_put_dir(directory, remote_dir)
    print "%s:(4/11) End to Transmist the op file" % host
    print "%s:(5/11) Begin to Collect the host information" % host
    nc._exec_comamnd("python %s" % remote_exec_file)
    print "%s:(6/11) End to Colect information" % host
    file_name = nc._exec_comamnd("cd %s && ls ServerReport-*.html" % remote_report_dir)[0].strip('\n')
    remote_report_file = os.path.join(remote_report_dir,file_name)
    local_file = os.path.join(local_file_dir,file_name)
    print "%s:(7/11) Begin to Transmist the collection file" % host
    nc._sftp_get(remote_report_file, local_file)
    print "%s:(8/11) End to Transmist the collection file" % host
    print "%s:(9/11) Begin to remove the op file" % host
    nc._exec_comamnd("rm -rf %s" % remote_report_dir)
    print "%s:(10/11) End to remove the op file" % host
    print "%s:(11/11) End the all operation" % host
    
host_file = ConfigrationParse.HostFile
try: 
    hinfo = open(host_file, 'r')
    _hinfo = hinfo.readlines()
    hinfo.close()
except:
    print "host.txt can't be open,Please check"
    sys.exit()
host_list = []
for h in _hinfo:
    host_list.append(h.strip('\n'))

threads = []
nloops = range(len(host_list))
for i in nloops:
    t = MyThread(_generate_report,(directory, host_list[i], 22, 'root'),host_list[i])
    threads.append(t)
for i in nloops:
    print "%s:(1/11) Begin to Apply" % host_list[i]
    threads[i].start()
for i in nloops:
    print "%s:(1/11) Begin to Apply" % host_list[i]
    threads[i].join()

  