程序用来批量收集服务器信息，并生成html格式报告，可用word打开
执行
python start.py 开始多线程收集信息

执行python generate.py 收集本机信息

收集的信息存放在程序所在目录的上一级目录的Report文件夹中

收集的信息定义在 setting中 包括
收集哪些主机
hosts.txt

收集哪些信息，执行命令或者收集文件
在info.basic.txt

主机 密码在setting/config.ini中
可以支持密钥认证，具体看源码