import os
import paramiko

#host = 
#port = 22
#user = 'root'
#local_dir = 

class OP_LOCAL_DIR():
    def __init__(self, directory, host, port, user, password=None):
        self._dir = directory
        self._host = host
        self._port = port
        self._user = user
        self._password = password
    def _ssh_connect(self):
        s = paramiko.SSHClient()
        s.load_system_host_keys()
        s.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        if self._password is None:
            pkey_file = '/root/.ssh/id_rsa'
            key = paramiko.RSAKey.from_private_key_file(pkey_file)
            s.connect(self._host,self._port,self._user,pkey=key,timeout=5)
        else:
            s.connect(self._host,self._port,self._user,self._password,timeout=5)
        return s
    def _exec_comamnd(self, cmd):
        s = self._ssh_connect()
        _,stdout,stderr = s.exec_command(cmd)
        cmd_result = stdout.read(),stderr.read()
        return cmd_result
    def _get_all_file_in_local_dir(self, _local_dir):
        if os.path.isdir(_local_dir):
            return list(os.walk(_local_dir))
    def _sftp_connect(self):
        s = paramiko.Transport((self._host, self._port))
        if self._password is None:
            pkey_file = '/root/.ssh/id_rsa'
            key = paramiko.RSAKey.from_private_key_file(pkey_file)
            s.connect(username=self._user,pkey=key)
        else:
            s.connect(username=self._user,password=self._password)
        sftp = paramiko.SFTPClient.from_transport(s)
        return sftp
    def _sftp_put(self, _sftp, local_file, remote_file):
        _sftp.put(local_file, remote_file)
    def _sftp_get(self, remote_file, local_file):
        _sftp = self._sftp_connect()
        _sftp.get(remote_file, local_file)
    def _sftp_mkdir(self, _sftp, remote_dir):
        _sftp.mkdir(remote_dir)
    def _sftp_put_dir(self, local_dir, remote_dir):
        _sftp = self._sftp_connect()
        for _single_dir in self._get_all_file_in_local_dir(local_dir):
            _single_local_dir = _single_dir[0]
            _single_local_file = _single_dir[2]
            if not len(_single_local_dir) == 0:
                _remote_dir = os.path.join(remote_dir, _single_local_dir)
                self._sftp_mkdir(_sftp, _remote_dir)
            for _single_file in _single_local_file:
                _local_file = os.path.join(_single_local_dir,_single_file)
                _remote_file = os.path.join(_remote_dir,_single_file)
                self._sftp_put(_sftp, _local_file, _remote_file)